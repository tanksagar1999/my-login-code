

const Product = require('../../models/product')

function homeController() {
    return{
        async index(req, res) {
            const item1 = await Product.find()
            
            return res.render('home', { item1:item1 })
            
            }
           
    }
   }
         
    
    

module.exports = homeController